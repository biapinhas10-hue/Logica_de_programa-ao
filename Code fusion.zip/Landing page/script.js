// Captura elementos globais do Modal de Checkout
const modal = document.getElementById("modalCheckout");
const botoesAbrir = document.querySelectorAll(".btn-abrir-checkout");
const botaoFechar = document.querySelector(".close-modal");
const areaStatus = document.getElementById("areaStatusPagamento");

// Abre o modal de Checkout em qualquer página ao clicar no botão de inscrição
botoesAbrir.forEach(botao => {
    botao.addEventListener("click", () => {
        if (areaStatus) areaStatus.innerHTML = ""; // Limpa transações anteriores
        if (modal) modal.style.display = "flex";
    });
});

// Fecha o modal ao clicar no 'X'
if(botaoFechar) {
    botaoFechar.addEventListener("click", () => {
        modal.style.display = "none";
    });
}

// Fecha o modal se clicar na área escura (fora da caixinha central)
window.addEventListener("click", (evento) => {
    if (evento.target === modal) {
        modal.style.display = "none";
    }
});

// Lógica para Processar o Método Selecionado (Pix ou Cartão)
function selecionarMetodo(metodo) {
    if (!areaStatus) return;

    areaStatus.style.color = "var(--blue-neon)";
    areaStatus.innerHTML = `⏳ Processando transação via ${metodo}...`;

    setTimeout(() => {
        if (metodo === 'PIX') {
            areaStatus.style.color = "#10b981"; // Verde Sucesso
            areaStatus.innerHTML = `
                <div style="border: 1px dashed var(--blue-neon); padding: 15px; margin-top: 10px; border-radius: 6px; background: rgba(0,0,0,0.3);">
                    <p style="margin-bottom: 10px; color: #fff;">Chave Copiada! Pague no aplicativo do seu banco:</p>
                    <code style="word-break: break-all; font-size: 0.85rem; color: var(--blue-neon); user-select: all;">00020101021126580014br.gov.bcb.pix0136codefusion2026eventopix520400005303986</code>
                </div>
            `;
        } else if (metodo === 'Cartão de Crédito') {
            areaStatus.style.color = "#10b981";
            areaStatus.innerHTML = "✅ Redirecionando para a página de dados do cartão...";
            
            // Redireciona o usuário para a nova página de cartão após 1 segundo
            setTimeout(() => {
                window.location.href = "cartao.html";
            }, 1000);
        }
    }, 1200);
}

// Função acionada quando o formulário da página cartao.html é enviado
function finalizarCompraCartao(event) {
    event.preventDefault(); // Impede a página de recarregar
    
    const botaoEnvio = document.querySelector(".btn-submit-pay");
    botaoEnvio.innerText = "Processando Dados...";
    botaoEnvio.disabled = true;

    // Simula aprovação da operadora de cartão
    setTimeout(() => {
        alert("🎉 Pagamento Aprovado com Sucesso! Sua vaga no CodeFusion 2026 está garantida. Verifique seu e-mail.");
        window.location.href = "index.html"; // Retorna para a página inicial
    }, 2000);
}