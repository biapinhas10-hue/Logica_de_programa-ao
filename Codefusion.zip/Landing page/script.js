/* ==========================================================================
   FUNÇÃO DE INSCRIÇÃO (BOTÃO GARANTIR VAGA)
   ========================================================================== */
function inscrever() {
    // Exibe uma caixa de confirmação simples no navegador
    const confirmacao = confirm("Deseja iniciar sua inscrição para o CodeFusion 2026?");
    
    if (confirmacao) {
        // Mensagem de sucesso caso o usuário clique em "OK"
        alert("Parabéns! Você foi redirecionado para o formulário de inscrição seguro.");
        
        // Exemplo: Se você tiver um link do Sympla ou Google Forms, 
        // basta descomentar a linha abaixo e colocar o link da sua inscrição:
        // window.location.href = "https://seu-link-de-inscricao.com";
    }
}

/* ==========================================================================
   ANIMAÇÃO SUAVE AO CLICAR NOS LINKS DO MENU (OPCIONAL)
   ========================================================================== */
// Esse bloco garante que todas as interações de clique na navbar sejam limpas e rápidas
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        console.log(`Navegando para a página: ${link.textContent}`);
    });
});