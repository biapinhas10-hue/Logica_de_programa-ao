document.addEventListener("DOMContentLoaded", function() {
    
    // 1. ROLAGEM SUAVE
    const linksInternos = document.querySelectorAll('nav a, .hero-buttons a');
    linksInternos.forEach(link => {
        link.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId.startsWith('#')) {
                e.preventDefault();
                const targetSection = document.querySelector(targetId);
                if (targetSection) {
                    targetSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
        });
    });

    // 2. CRIAÇÃO DO MODAL DINÂMICO INTERATIVO (Cadastro + Menu de Opções + Telas Finais)
    const modalHTML = `
        <div id="customModal" class="modal-overlay" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.7); z-index:2000; justify-content:center; align-items:center;">
            <div class="modal-content" style="background:#fff; padding:30px; border-radius:8px; width:90%; max-width:420px; position:relative; box-shadow: 0 4px 20px rgba(0,0,0,0.2);">
                <span class="close-modal" style="position:absolute; top:15px; right:20px; font-size:1.5rem; cursor:pointer; color:#666;">&times;</span>
                <h3 id="modalTitle" style="margin-bottom:20px; font-weight:800; color:#0b1520;">INICIAR MATRÍCULA</h3>
                
                <form id="enrollmentForm">
                    <div style="margin-bottom:15px;">
                        <label style="display:block; font-weight:600; font-size:0.85rem;">Nome Completo</label>
                        <input type="text" required>
                    </div>
                    <div style="margin-bottom:15px;">
                        <label style="display:block; font-weight:600; font-size:0.85rem;">E-mail</label>
                        <input type="email" required>
                    </div>
                    <div style="margin-bottom:20px;">
                        <label style="display:block; font-weight:600; font-size:0.85rem;">Telefone / WhatsApp</label>
                        <input type="tel" required placeholder="(11) 99999-9999">
                    </div>
                    <button type="submit" style="width:100%; background:#8fa843; color:#fff; border:none; padding:12px; font-weight:700; cursor:pointer; border-radius:4px;">PRÓXIMO PASSO</button>
                </form>

                <div id="paymentSection" style="display:none; text-align:center;">
                    <p style="margin-bottom:20px; font-size:0.95rem; color:#555;">Escolha a forma de pagamento:</p>
                    <button id="btnPix" style="width:100%; background:#32bcad; color:#fff; border:none; padding:12px; font-weight:700; cursor:pointer; border-radius:4px; margin-bottom:12px; display:flex; align-items:center; justify-content:center; gap:10px;">
                        <i class="fa-solid fa-qrcode"></i> Pagar com PIX
                    </button>
                    <button id="btnCartao" style="width:100%; background:#0b1520; color:#fff; border:none; padding:12px; font-weight:700; cursor:pointer; border-radius:4px; display:flex; align-items:center; justify-content:center; gap:10px;">
                        <i class="fa-solid fa-credit-card"></i> Cartão de Crédito
                    </button>
                </div>

                <div id="pixScreen" style="display:none; text-align:center;">
                    <i class="fa-solid fa-circle-check" style="font-size:2.5rem; color:#32bcad; margin-bottom:15px;"></i>
                    <p style="font-size:0.9rem; margin-bottom:15px; color:#333;">Código PIX Copia e Cola gerado com sucesso!</p>
                    <textarea id="pixCode" readonly style="width:100%; height:70px; padding:10px; border:1px dashed #32bcad; background:#f4fbfb; border-radius:4px; font-family:monospace; font-size:0.75rem; resize:none; margin-bottom:15px;">00020101021226830014br.gov.bcb.pix2561fitnessacademiavinculadadecheckoutficticia20260520400005303986540579.905802BR5924FitnessAcademiaLTDA6009SaoPaulo62070503***</textarea>
                    <button id="btnCopyPix" style="width:100%; background:#32bcad; color:#fff; border:none; padding:12px; font-weight:700; cursor:pointer; border-radius:4px;">COPIAR CÓDIGO PIX</button>
                </div>

                <form id="cardForm" style="display:none;">
                    <div style="margin-bottom:12px;">
                        <label style="display:block; font-weight:600; font-size:0.85rem;">Número do Cartão</label>
                        <input type="text" placeholder="0000 0000 0000 0000" required maxlength="19">
                    </div>
                    <div style="margin-bottom:12px;">
                        <label style="display:block; font-weight:600; font-size:0.85rem;">Nome Impresso no Cartão</label>
                        <input type="text" placeholder="NOME DO TITULAR" required>
                    </div>
                    <div style="display:flex; gap:15px; margin-bottom:20px;">
                        <div style="flex:1;">
                            <label style="display:block; font-weight:600; font-size:0.85rem;">Validade</label>
                            <input type="text" placeholder="MM/AA" required maxlength="5">
                        </div>
                        <div style="flex:1;">
                            <label style="display:block; font-weight:600; font-size:0.85rem;">CVV</label>
                            <input type="text" placeholder="000" required maxlength="4">
                        </div>
                    </div>
                    <button type="submit" style="width:100%; background:#0b1520; color:#fff; border:none; padding:12px; font-weight:700; cursor:pointer; border-radius:4px;">FINALIZAR PAGAMENTO</button>
                </form>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHTML);

    const modal = document.getElementById('customModal');
    const closeModal = document.querySelector('.close-modal');
    const modalTitle = document.getElementById('modalTitle');
    const formEnrollment = document.getElementById('enrollmentForm');
    const paymentSection = document.getElementById('paymentSection');
    const pixScreen = document.getElementById('pixScreen');
    const cardForm = document.getElementById('cardForm');

    // Reseta todas as visualizações internas do modal ao abrir
    window.openModal = function(titulo, apenasPagamento = false) {
        modalTitle.textContent = titulo;
        modal.style.display = 'flex';
        
        formEnrollment.style.display = apenasPagamento ? 'none' : 'block';
        paymentSection.style.display = apenasPagamento ? 'block' : 'none';
        pixScreen.style.display = 'none';
        cardForm.style.display = 'none';
    };

    closeModal.addEventListener('click', () => modal.style.display = 'none');
    window.addEventListener('click', (e) => { if (e.target === modal) modal.style.display = 'none'; });

    // 3. CAPTURA DOS BOTÕES DA PÁGINA
    document.querySelectorAll('.btn-cta, .btn-cta-large').forEach(btn => {
        btn.addEventListener('click', () => openModal('PROMOÇÃO DE INAUGURAÇÃO'));
    });
    document.querySelector('.btn-secondary').addEventListener('click', () => openModal('AGENDAR VISITA GRATUITA'));

    document.querySelectorAll('.plano-card').forEach(card => {
        const nomePlano = card.querySelector('h3').textContent;
        card.querySelector('.btn-plano').addEventListener('click', () => openModal(`INSCRIÇÃO: PLANO ${nomePlano}`));
        card.querySelector('.btn-pagar').addEventListener('click', () => openModal(`PAGAMENTO: PLANO ${nomePlano}`, true));
    });

    // 4. FLUXO AVANÇAR: CADASTRO -> ESCOLHA DO PAGAMENTO
    formEnrollment.addEventListener('submit', function(e) {
        e.preventDefault();
        modalTitle.textContent = "FORMA DE PAGAMENTO";
        formEnrollment.style.display = 'none';
        paymentSection.style.display = 'block';
    });

    // 5. SELEÇÃO DO MÉTODO DE PAGAMENTO
    // Clicou em PIX
    document.getElementById('btnPix').addEventListener('click', () => {
        modalTitle.textContent = "PAGAMENTO VIA PIX";
        paymentSection.style.display = 'none';
        pixScreen.style.display = 'block';
    });

    // Clicou em Cartão
    document.getElementById('btnCartao').addEventListener('click', () => {
        modalTitle.textContent = "DADOS DO CARTÃO";
        paymentSection.style.display = 'none';
        cardForm.style.display = 'block';
    });

    // 6. AÇÕES FINAIS (Copiar PIX e Enviar Cartão)
    document.getElementById('btnCopyPix').addEventListener('click', () => {
        const copyText = document.getElementById('pixCode');
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(copyText.value);
        
        alert("Código PIX copiado! Cole no aplicativo do seu banco para concluir a sua matrícula.");
        modal.style.display = 'none';
        formEnrollment.reset();
    });

    cardForm.addEventListener('submit', function(e) {
        e.preventDefault();
        alert("Pagamento processado com sucesso! Seu acesso já está liberado. Bem-vindo(a) à Fitness Academia!");
        modal.style.display = 'none';
        formEnrollment.reset();
        cardForm.reset();
    });
});