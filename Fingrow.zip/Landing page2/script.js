/* ========================================================
   1. SISTEMA GERENCIADOR DO MODAL INTERATIVO
   ======================================================== */
const modal = document.getElementById('custom-modal');
const modalContent = document.getElementById('modal-content-area');
const closeModalBtn = document.getElementById('close-modal');

// Função centralizada para abrir o modal com conteúdos customizados
function openModal(htmlContent) {
    modalContent.innerHTML = htmlContent;
    modal.classList.add('active');
}

// Fechar o modal ao clicar no 'X' ou fora dele
closeModalBtn.addEventListener('click', () => modal.classList.remove('active'));
window.addEventListener('click', (e) => { if (e.target === modal) modal.classList.remove('active'); });

/* ========================================================
   2. MAPEAMENTO DE FUNCIONALIDADE DOS BOTÕES
   ======================================================== */
document.addEventListener('click', (e) => {
    // Captura o clique baseado no atributo 'data-action'
    const target = e.target;
    const action = target.getAttribute('data-action');

    if (!action) return;

    // Ação: Baixar Aplicativo
    if (action === 'download') {
        openModal(`
            <div class="modal-body">
                <i class="fa-solid fa-mobile-screen-button" style="font-size: 3.5rem; color: var(--primary-green); margin-bottom:1rem;"></i>
                <h3>Baixar o FinGrow</h3>
                <p>Escaneie o QR Code ou escolha sua loja de aplicativos para começar a controlar seus gastos agora mesmo.</p>
                <div style="display:flex; justify-content:center; gap:1rem; margin-top:1rem;">
                    <button class="btn-primary" onclick="alert('Redirecionando para a Google Play Store...')"><i class="fa-brands fa-google-play"></i> Android</button>
                    <button class="btn-primary" onclick="alert('Redirecionando para a Apple App Store...')"><i class="fa-brands fa-apple"></i> iOS</button>
                </div>
            </div>
        `);
    }

    // Ação: Escolha de Planos (Checkout fake dinâmico)
    if (action === 'plan') {
        const planName = target.getAttribute('data-plan');
        const planPrice = target.getAttribute('data-price') || '19,90';
        openModal(`
            <div class="modal-body">
                <i class="fa-solid fa-credit-card" style="font-size: 3.5rem; color: var(--primary-green); margin-bottom:1rem;"></i>
                <h3>Assinar Plano ${planName}</h3>
                <p>Você está a um passo de evoluir sua vida financeira por apenas <strong>R$ ${planPrice}/mês</strong>.</p>
                <input type="text" placeholder="Seu Nome Completo" class="modal-input">
                <input type="email" placeholder="Seu Melhor E-mail" class="modal-input">
                <button class="btn-plan-featured" style="margin-top:1rem;" onclick="alert('🚀 Cadastro simulado com sucesso! Seja bem-vindo ao FinGrow.')">Confirmar e Ir para o Pagamento</button>
            </div>
        `);
    }
});

// Extra: Notificação Interativa do Sininho do Celular
const appBell = document.getElementById('app-bell');
if(appBell) {
    appBell.addEventListener('click', () => {
        alert('🔔 FinGrow Alerta: Você economizou R$ 85,00 esta semana com as dicas da IA!');
    });
}

/* ========================================================
   3. ROLAGEM SUAVE INTEGRADA (Smooth Scroll)
   ======================================================== */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);
        
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

/* ========================================================
   4. EFEITOS VISUAIS (Tilt 3D e Revelação)
   ======================================================== */
const mockup = document.querySelector('.app-mockup');
if(mockup) {
    mockup.addEventListener('mousemove', (e) => {
        const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
        const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
        mockup.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
    });
    mockup.addEventListener('mouseleave', () => {
        mockup.style.transform = 'rotateY(0deg) rotateX(0deg)';
    });
}