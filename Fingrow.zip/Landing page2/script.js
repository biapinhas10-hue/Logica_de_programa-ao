/* ========================================================
   1. SISTEMA GERENCIADOR DO MODAL INTERATIVO
   ======================================================== */
const modal = document.getElementById('custom-modal');
const modalContent = document.getElementById('modal-content-area');
const closeModalBtn = document.getElementById('close-modal');

function openModal(htmlContent) {
    modalContent.innerHTML = htmlContent;
    modal.classList.add('active');
}

closeModalBtn.addEventListener('click', () => modal.classList.remove('active'));
window.addEventListener('click', (e) => { if (e.target === modal) modal.classList.remove('active'); });

/* ========================================================
   2. MAPEAMENTO DE INTERAÇÃO DOS BOTÕES E PAGAMENTOS
   ======================================================== */
document.addEventListener('click', (e) => {
    const target = e.target;
    const action = target.getAttribute('data-action');

    if (!action) return;

    // Ação: Download do App
    if (action === 'download') {
        openModal(`
            <div class="modal-body">
                <i class="fa-solid fa-mobile-screen-button" style="font-size: 3.5rem; color: var(--primary-green); margin-bottom:1rem;"></i>
                <h3>Baixar o FinGrow</h3>
                <p>Escaneie o QR Code ou escolha sua loja de aplicativos para começar a controlar seus gastos agora mesmo.</p>
                <div style="display:flex; justify-content:center; gap:1rem; margin-top:1rem;">
                    <button class="btn-primary" onclick="alert('Redirecionando para a Google Play Store...')"><i class="fa-brands fa-google-play"></i> Android</button>
                    <button class="btn-primary" onclick="alert('Redirecionando para a Apple App Store...')"><i class="fa-brands fa-apple"></i> iOS</button>
                </div>
            </div>
        `);
    }

    // Ação: Abertura e configuração do Checkout
    if (action === 'plan') {
        const planName = target.getAttribute('data-plan');
        const planPrice = target.getAttribute('data-price') || '19,90';
        
        // Inicia o fluxo mostrando a opção de Cartão por padrão
        renderCheckoutModal(planName, planPrice, 'card');
    }

    // Ação Alternar Aba dentro do Modal: Mudar para PIX
    if (action === 'switch-pix') {
        const pName = target.getAttribute('data-plan');
        const pPrice = target.getAttribute('data-price');
        renderCheckoutModal(pName, pPrice, 'pix');
    }

    // Ação Alternar Aba dentro do Modal: Mudar para CARTÃO
    if (action === 'switch-card') {
        const pName = target.getAttribute('data-plan');
        const pPrice = target.getAttribute('data-price');
        renderCheckoutModal(pName, pPrice, 'card');
    }
});

/* ========================================================
   3. FUNÇÃO AUXILIAR PARA MONTAR A TELA DE CHECKOUT (PIX OU CARTÃO)
   ======================================================== */
function renderCheckoutModal(planName, planPrice, activeMethod) {
    let formContent = '';

    if (activeMethod === 'card') {
        // Renderiza o formulário de Cartão de Crédito
        formContent = `
            <div class="payment-form-area">
                <input type="text" placeholder="Nome Completo do Titular" class="modal-input">
                <input type="text" placeholder="Número do Cartão (0000 0000 0000 0000)" class="modal-input">
                <div class="input-row">
                    <input type="text" placeholder="Validade (MM/AA)" class="modal-input">
                    <input type="text" placeholder="CVV" class="modal-input">
                </div>
                <button class="btn-plan-featured" style="margin-top: 1rem;" onclick="alert('💳 Pagamento via Cartão Processado! Seu plano ${planName} já está ativo.')">Confirmar Assinatura</button>
            </div>
        `;
    } else {
        // Renderiza o painel com QR Code e Chave Pix copia e cola
        formContent = `
            <div class="pix-container">
                <div class="pix-qr-placeholder">
                    <i class="fa-solid fa-qrcode"></i>
                </div>
                <p style="margin-bottom: 0.5rem; font-size:0.9rem;">Copie o código abaixo para pagar no seu banco:</p>
                <div class="pix-code-box">00020101021126580014br.gov.bcb.pix0136fingrow-fake-pix-key-2026-prod-999</div>
                <button class="btn-plan" style="width: auto; padding: 0.6rem 1.5rem;" onclick="navigator.clipboard.writeText('00020101021126580014br.gov.bcb.pix0136fingrow-fake-pix-key-2026-prod-999'); alert('📋 Código Pix copiado para a área de transferência!');">Copiar Código PIX</button>
            </div>
        `;
    }

    // Injeta a estrutura completa das abas e o formulário ativo no modal
    openModal(`
        <div class="modal-body">
            <h3>Assinar Plano ${planName}</h3>
            <p>Valor total: <strong>R$ ${planPrice}/mês</strong></p>
            
            <div class="payment-methods">
                <button class="btn-method ${activeMethod === 'card' ? 'active' : ''}" data-action="switch-card" data-plan="${planName}" data-price="${planPrice}">
                    <i class="fa-solid fa-credit-card"></i> Cartão
                </button>
                <button class="btn-method ${activeMethod === 'pix' ? 'active' : ''}" data-action="switch-pix" data-plan="${planName}" data-price="${planPrice}">
                    <i class="fa-solid fa-pix"></i> Pix
                </button>
            </div>

            ${formContent}
        </div>
    `);
}

// Extra: Notificação Interativa do Sininho do Celular
const appBell = document.getElementById('app-bell');
if(appBell) {
    appBell.addEventListener('click', () => {
        alert('🔔 FinGrow Alerta: Você economizou R$ 85,00 esta semana com as dicas da IA!');
    });
}

/* ========================================================
   4. ROLAGEM SUAVE INTEGRADA (Smooth Scroll)
   ======================================================== */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);
        
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

/* ========================================================
   5. EFEITOS VISUAIS (Tilt 3D e Revelação)
   ======================================================== */
const mockup = document.querySelector('.app-mockup');
if(mockup) {
    mockup.addEventListener('mousemove', (e) => {
        const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
        const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
        mockup.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
    });
    mockup.addEventListener('mouseleave', () => {
        mockup.style.transform = 'rotateY(0deg) rotateX(0deg)';
    });
}